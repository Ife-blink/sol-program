use anchor_lang::prelude::*;
use solana_program::entrypoint::ProgramResult;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};


declare_id!("BkX9sBaAcqb1wA5KGnGP8MAxaXZRphg7GaoLUfokHKva");


#[program]
pub mod prvn_program {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> ProgramResult {
        let data = &mut ctx.accounts.data;
        data.manufacturer_id = *ctx.accounts.user.key;
        data.batch_id = 1.to_string();
        data.expiration_date = 0; // Set expiration date as needed
        data.product_id_counter = 0;
        Ok(())
    }


     pub fn create_manufacturer(ctx: Context<CreateManufacturer>, business_name: String) -> ProgramResult {
        let data = &mut ctx.accounts.data;
        data.manufacturer_id = *ctx.accounts.user.key;
        data.business_name = business_name;
        data.user_type = UserType::Manufacturer;

        Ok(())
    }

    pub fn create_consumer(ctx: Context<CreateConsumer>, consumer_name: String) -> ProgramResult {
        let data = &mut ctx.accounts.data;
        data.consumer_id = *ctx.accounts.user.key;
        data.consumer_name = consumer_name;
        data.user_type = UserType::Consumer;
        Ok(())
    }

    pub fn create_store(ctx: Context<CreateStore>, store_name: String, location: String) -> ProgramResult {
        let data = &mut ctx.accounts.data;
        data.store_id = *ctx.accounts.user.key;
        data.store_name = store_name;
        data.location = location;
        data.user_type = UserType::Store;
        Ok(())
    }


    pub fn tag_product(ctx: Context<Tag>, random_hash: u64) -> ProgramResult {
        let data = &mut ctx.accounts.data;

        let user = ctx.accounts.user_data;

        if user != UserType::Manufacturer {
        return Err(ErrorCode::UnauthorizedUser.into());
        }
        
        data.random_hash = random_hash;
        data.product_id_counter += 1;

        let mut hasher = DefaultHasher::new();
        data.manufacturer_id.hash(&mut hasher);
        data.batch_id.hash(&mut hasher);
        data.product_id_counter.hash(&mut hasher);
        data.unique_hash = hasher.finish();

        Ok(())
    }

    pub fn get_value(ctx: Context<GetValue>) -> ProgramResult {
        let data = &ctx.accounts.data;
        msg!("Value: {}", data.unique_hash);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(init, payer = user, space = 8 + 4 + 8 + 8 + 8 + 8)]
    pub data: Account<'info, ProductData>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct GetUserInfo<'info> {
    #[account(signer)]
    pub user: AccountInfo<'info>,
    pub data: Account<'info, Manufacturer>,
}

#[derive(Accounts)]
pub struct CreateManufacturer<'info> {
    #[account(init, payer = user, space = 8 + 4 + 4 + 32)]
    pub data: Account<'info, Manufacturer>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}



#[derive(Accounts)]
pub struct CreateConsumer<'info> {
    #[account(init, payer = user, space = 8 + 4 + 4 + 32)]
    pub data: Account<'info, Consumer>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateStore<'info> {
    #[account(init, payer = user, space = 8 + 4 + 4 + 32 + 64)]
    pub data: Account<'info, Store>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}


#[derive(Accounts)]
pub struct Tag<'info> {
    #[account(init, payer = user, space = 8 + 4)]
    pub data: Account<'info, ProductData>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub user_data: Account<'info, UserType>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct GetValue<'info> {
    #[account()]
    pub data: Account<'info, ProductData>,
}

#[account]
pub struct ProductData {
    pub manufacturer_id: Pubkey,
    pub batch_id: String,
    pub expiration_date: u64,
    pub random_hash: u64,
    pub product_id_counter: u32,
    pub unique_hash: u64,
}

#[account]
pub struct UserInfo {
    pub user_type: UserType,
}

#[account]
pub struct Manufacturer {
    pub manufacturer_id: Pubkey,
    pub business_name: String,
    pub user_type: UserType,
}

#[account]
pub struct Store {
    pub store_id: Pubkey,
    pub store_name: String,
    pub location: String,
    pub user_type: UserType,
}

#[account]
pub struct Consumer {
    pub consumer_id: Pubkey,
    pub consumer_name: String,
    pub user_type: UserType,
}


#[derive(Debug, AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq)]
pub enum UserType {
    Manufacturer,
    Consumer,
    Store,
}

impl Default for UserType {
    fn default() -> Self {
        UserType::Consumer
    }
}

impl AccountDeserialize for UserType {}

#[error_code]
pub enum ErrorCode {
    #[msg("Unauthorized user")]
    UnauthorizedUser,
}

impl From<ErrorCode> for ProgramError {
    fn from(error: ErrorCode) -> Self {
        ProgramError::Custom(error as u32)
    }
}